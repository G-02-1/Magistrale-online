from flask import Flask, request, render_template, jsonify, redirect, url_for

app = Flask(__name__)
app.config['TEMPLATES_AUTO_RELOAD'] = True

messages = []  # Store messages for the stored XSS example

@app.route('/')
def index():
    return render_template('index.html')

# Reflected XSS example - Insecurely rendering user input 
@app.route('/reflected-xss')
def reflected_xss():
    name = request.args.get('name', '')
    return f"<h2>Hello {name}!</h2>"

# Stored XSS example - Insecurely storing and rendering user input
@app.route('/stored-xss', methods=['GET', 'POST']) 
def stored_xss():
    if request.method == 'POST':
        message = request.form['message']
        messages.append(message)
    enumerated_messages = list(enumerate(messages))
    return render_template('stored_xss.html', messages=enumerated_messages)


# Endpoint to remove a message
@app.route('/remove_message/<int:index>', methods=['POST'])
def remove_message(index):
    if 0 <= index < len(messages):
        messages.pop(index)
    return redirect(url_for('stored_xss'))

# DOM XSS example - Insecurely handling user input in JavaScript
@app.route('/dom-xss') 
def dom_xss():
    return render_template('dom_xss.html')

@app.route('/api/dom-xss', methods=['POST'])
def dom_xss_api():
    return jsonify({"message": request.json['message']})

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
