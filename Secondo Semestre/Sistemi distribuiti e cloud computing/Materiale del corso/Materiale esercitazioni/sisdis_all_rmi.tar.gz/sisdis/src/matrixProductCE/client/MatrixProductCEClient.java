package matrixProductCE.client;

import java.util.Vector;

import scalarProductCE.client.ScalarProductJob;

import computeEngine.client.ComputeThread;

public class MatrixProductCEClient {
	public static void main(String args[]) {
		int[][] mat1 = new int[2][3];
		int[][] mat2 = new int[3][2];
		int v = 0;
		// populate “mat1” and “mat2” (in a naive way)
		for (int i = 0; i < mat1.length; i++)
			for (int j = 0; j < mat1[0].length; j++)
				mat1[i][j] = ++v;
		for (int i = 0; i < mat2.length; i++)
			for (int j = 0; j < mat2[0].length; j++)
				mat2[i][j] = (i == j ? 1 : 0);

		printMatrix(mat1,"Matrice 1");
		printMatrix(mat2,"Matrice 2");
		
		Vector threads = new Vector();
		for (int c = 0; c < mat2[0].length; c++)
			for (int r = 0; r < mat1.length; r++) {
				Vector vpar = new Vector();
				vpar.add(extractColumn(mat2, c));
				vpar.add(extractRow(mat1, r));
				ComputeThread ct = new ComputeThread(new ScalarProductJob(),
						vpar, "localhost");
				threads.add(ct);
			}
		for (int i = 0; i < threads.size(); i++)
			((Thread) threads.get(i)).start();
		try {
			for (int i = 0; i < threads.size(); i++)
				((Thread) threads.get(i)).join();
		} catch (InterruptedException e) {
			System.out.println(e);
		}

		int[][] result = new int[mat1.length][mat2[0].length];
		for (int i = 0; i < threads.size(); i++) {
			int r = ((Integer) ((ComputeThread) threads.get(i)).getResult())
					.intValue();
			result[i % mat1.length][i / mat1.length] = r; // see next slide

		}

//		for (int i = 0; i < result.length; i++) {
//			System.out.println();
//			for (int j = 0; j < result[0].length; j++)
//				System.out.print(result[i][j] + " ");
//		}
		
		printMatrix(result,"Matrice1 x Matrice 2");
	}

	private static Vector extractRow(int[][] mat, int rowIndex) {
		Vector ret = new Vector();
		for (int c = 0; c < mat[0].length; c++)
			ret.add(new Integer(mat[rowIndex][c]));
		return ret;
	}

	private static Vector extractColumn(int[][] mat, int columnIndex) {
		Vector ret = new Vector();
		for (int r = 0; r < mat.length; r++)
			ret.add(new Integer(mat[r][columnIndex]));
		return ret;
	}
	
	private static void printMatrix(int[][] matrice, String name){
		System.out.println("\n**** "+name+" ****");
		for (int i = 0; i < matrice.length; i++){
			System.out.print("[\t");
			for (int j = 0; j < matrice[0].length; j++){
				System.out.print(matrice[i][j]+"\t");
			}
			System.out.print("]\n");
		}
		System.out.print("\n");
	}
}
