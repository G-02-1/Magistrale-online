package timeMonitor.client;
import java.rmi.RemoteException;
import java.util.Date;
public interface TimeMonitor extends java.rmi.Remote {	
	public void time(Date d) throws RemoteException;
}
