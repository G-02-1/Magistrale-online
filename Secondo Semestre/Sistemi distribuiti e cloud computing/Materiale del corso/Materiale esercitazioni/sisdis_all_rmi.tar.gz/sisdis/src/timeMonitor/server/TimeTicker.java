package timeMonitor.server;

import java.util.Date;

import timeMonitor.client.TimeMonitor;

class TimeTicker extends Thread {
	private TimeMonitor tm;

	TimeTicker(TimeMonitor tm) {
		this.tm = tm;
	}

	public void run()	{	
   		while (true) {
			try {
				tm.time(new Date());
				sleep( 2000 );	
			} catch (Exception e) {
				e.printStackTrace();
			}

		}//while
	}//run
} // TimeTicker class
