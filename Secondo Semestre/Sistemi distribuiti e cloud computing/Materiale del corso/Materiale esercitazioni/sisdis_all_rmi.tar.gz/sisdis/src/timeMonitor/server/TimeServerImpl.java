package timeMonitor.server;

import java.rmi.Naming;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.server.UnicastRemoteObject;

import timeMonitor.client.TimeMonitor;

public class TimeServerImpl extends UnicastRemoteObject implements TimeServer {
	
	protected TimeServerImpl() throws RemoteException {
		super();
	}

	private static TimeServerImpl tsi;

	public static void main(String[] args) {
		try {
			tsi = new TimeServerImpl();
			LocateRegistry.createRegistry(1099);
			System.out.println("Registry created");
			Naming.rebind("TimeServer", tsi);
			System.out.println("Bindings Finished");
			System.out.println("Waiting for Client requests");
		} catch (Exception e) {
			System.out.println(e);
		}
	} // main

	public void registerTimeMonitor(TimeMonitor tm) throws RemoteException {
		System.out.println("Client requesting a connection");
		TimeTicker tt;
		tt = new TimeTicker(tm);
		tt.start();
		System.out.println("Timer Started");

	} // class TimeServerImpl

}
