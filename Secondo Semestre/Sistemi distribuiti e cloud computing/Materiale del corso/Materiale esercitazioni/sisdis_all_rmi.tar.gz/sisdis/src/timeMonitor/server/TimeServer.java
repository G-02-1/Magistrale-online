package timeMonitor.server;
import java.rmi.RemoteException;

import timeMonitor.client.TimeMonitor;

public interface TimeServer extends java.rmi.Remote {	
	public void registerTimeMonitor(TimeMonitor tm)  
		throws RemoteException;
}
