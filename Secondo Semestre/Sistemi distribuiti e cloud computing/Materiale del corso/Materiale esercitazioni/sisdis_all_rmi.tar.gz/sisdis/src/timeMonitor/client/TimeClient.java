package timeMonitor.client;

import java.rmi.Naming;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.Date;

import timeMonitor.server.TimeServer;


public class TimeClient implements TimeMonitor {
	private TimeServer ts;

	public TimeClient() {
		try {
			System.out.println("Exporting the Client");
			UnicastRemoteObject.exportObject(this,1098);
			ts = (TimeServer) Naming.lookup("rmi://localhost:1099/TimeServer");
			ts.registerTimeMonitor(this);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public void time(Date d) throws RemoteException {
		System.out.println(d);
	}
	
	public static void main(String[] args) {
		new TimeClient();
	}
	
} // class TimeClient
