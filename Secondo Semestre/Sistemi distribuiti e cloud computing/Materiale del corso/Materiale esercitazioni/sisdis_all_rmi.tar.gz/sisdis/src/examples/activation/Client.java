package examples.activation; 

import java.rmi.*;
import java.rmi.registry.*;

public class Client {

    public static void main(String args[])  throws Exception {

        String server = "localhost";

        if (System.getSecurityManager() == null) {
            System.setSecurityManager(new SecurityManager());
        }

        String location = "rmi://" + server + "/ActivatableImplementation";
        MyRemoteInterface mri = (MyRemoteInterface)Naming.lookup(location);
        System.out.println("Got a remote reference to the object that extends Activatable.");
        
        String result = "failure";
        
        System.out.println("Making remote call to the server");
        result = (String) mri.callMeRemotely();
        
        System.out.println("Returned from remote call");
        System.out.println("Result: " + result);
    }
}