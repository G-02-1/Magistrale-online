package examples.activation;

import java.rmi.*;
import java.rmi.activation.*;
import java.rmi.registry.*;
import java.util.Properties;

public class Setup {

	/**
	 * This class registers information about the ActivatableImplementation
	 * class with rmid and the rmiregistry
	 */

	/**
	 * Private constructor to prevents instantiation.
	 */
	private Setup() {
	}

	public static void main(String[] args) throws Exception {

		if (System.getSecurityManager() == null) {
			System.setSecurityManager(new RMISecurityManager());
		}

		/*
		 * we should create the activation group descriptor, by passing the name
		 * of the java executable (if it is initialized to null, means “use
		 * rmid’s default”
		 */

		Properties props = new Properties();
		props.put("java.security.policy", "/home/loris/workspace/sisdis/policy.all");

		ActivationGroupDesc.CommandEnvironment ace = null;
		ActivationGroupDesc exampleGroup = new ActivationGroupDesc(props, null);

		// Once the ActivationGroupDesc has been created, register it with the
		// activation system to obtain its ID
		ActivationGroupID agi = ActivationGroup.getSystem().registerGroup(
				exampleGroup);
		System.out.println("Activation group descriptor registered.");

		// The "location" String specifies a URL from where the class definition
		// will come when this object is requested (activated).
		String location = "file:///home/loris/workspace/sisdis/bin/";
		
		

		// Create the rest of the parameters that will be passed to the
		// ActivationDesc constructor
		MarshalledObject data = null;

		// The location argument to the ActivationDesc constructor will be used
		// to uniquely identify this class; its location is relative to the URL-
		// formatted String, location.
		ActivationDesc desc = new ActivationDesc(agi,
				"examples.activation.ActivatableImplementation", location, data);

		// Register with rmid
		MyRemoteInterface mri = (MyRemoteInterface) Activatable.register(desc);
		System.out.println("Got the stub for the ActivatableImplementation");
		// Bind the stub to a name in the registry running on 1099
		Naming.rebind("ActivatableImplementation", mri);
		System.out.println("Exported ActivatableImplementation");
		System.exit(0);
	}
}
