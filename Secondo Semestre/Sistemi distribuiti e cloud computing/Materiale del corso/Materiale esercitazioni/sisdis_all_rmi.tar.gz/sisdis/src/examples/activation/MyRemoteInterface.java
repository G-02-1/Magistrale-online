package examples.activation;

import java.rmi.*;

public interface MyRemoteInterface extends Remote {
    Object callMeRemotely() throws RemoteException;
}