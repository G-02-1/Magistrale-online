package chat.server;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

public class ChatServerImpl extends UnicastRemoteObject implements
		ChatServer {

	protected ChatServerImpl() throws RemoteException {
		super();
	}

	@Override
	public void login(String name, String password) throws RemoteException {
		System.out.println("> ["+name+"] logged in!");
		
	}

	@Override
	public void logout(String name) throws RemoteException {
		System.out.println("> ["+name+"] logged out!");
		
	}

	@Override
	public void chat(String name, String message) throws RemoteException {
		System.out.println("> ["+name+"]: "+message);
		
	}

}