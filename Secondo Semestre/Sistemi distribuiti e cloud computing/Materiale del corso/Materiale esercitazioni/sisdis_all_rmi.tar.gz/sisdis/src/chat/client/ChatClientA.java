package chat.client;

import java.rmi.Naming;

import chat.server.ChatServer;

public class ChatClientA {
	
	public static void main(String[] argv) {
		try { 

			ChatServer server = (ChatServer) Naming.lookup("rmi://localhost/Chat");
			String name = "Pippo";
			String password = "password";
			
			server.login(name,password);
			server.chat(name, "Sono entrato in chat!");
			server.logout(name);

		} catch (Exception e) {
			System.out.println("[System] Server failed: " + e);
		}
	}
}