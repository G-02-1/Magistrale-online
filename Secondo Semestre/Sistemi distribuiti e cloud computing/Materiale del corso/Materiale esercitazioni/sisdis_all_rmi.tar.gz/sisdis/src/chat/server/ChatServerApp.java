package chat.server;

import java.rmi.Naming;

public class ChatServerApp {

	public ChatServerApp() {
		try {
			ChatServer server = new ChatServerImpl();
			Naming.rebind("rmi://localhost:1099/Chat", server);
			System.out.println("[System] Chat Remote Object is ready:");
		} catch (Exception e) {
			System.out.println("[System] Server failed: " + e);
		}
	}

	public static void main(String[] argv) {
		
		ChatServerApp p = new ChatServerApp();

	}
}