package dgc.server;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.rmi.server.Unreferenced;

public class MessageObjectImpl extends UnicastRemoteObject implements MessageObject, Unreferenced {	
	static  int number = 0;
  	static int totalNumber = 0; 
  	private int objNumber;
  	
	public MessageObjectImpl() throws RemoteException {	
		objNumber = ++number;
		totalNumber++;
		System.out.println( "MessageObject: Class Number is #" + totalNumber + 	" Object Number is #" +  objNumber );
	}

	@Override
	public void unreferenced() {
		System.out.println( "MessageObject: Unreferenced for object #: " + objNumber );
	}
	
	protected void finalize() throws Throwable {
			super.finalize();
			totalNumber--;
			System.out.println( "MessageObject: Finalize for object #: " + objNumber );
	}
	
	@Override
	public int getNumberFromObject() throws RemoteException {
		return objNumber;
	}

	@Override
	public int getNumberFromClass() throws RemoteException {
		return totalNumber;
	}

} // class MessageObjectImpl