package dgc.client;

import java.rmi.Naming;

import dgc.server.Hello;
import dgc.server.MessageObject;

public class RMIClient {

	private static final int PORT = 10007;
	private static final String HOST_NAME = "router";
	private static RMIClient rmi;

	public RMIClient() {
		try {
			Hello hello = (Hello) Naming.lookup("//" + HOST_NAME + ":" + PORT
					+ "/" + "Hello");
			System.out.println("HelloService lookup successful");
			System.out.println("Message from Server: " + hello.sayHello());
			MessageObject mo;
			for (int i = 0; i < 100; i++) {
				mo = hello.getMessageObject();
				System.out.println("MessageObject: ClassNumber is #"
						+ mo.getNumberFromClass() + " Object Number is #"
						+ mo.getNumberFromObject());
				mo = null;
				Thread.sleep(500);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public static void main(String[] args) {
		rmi = new RMIClient();
	}

} // class RMIClient