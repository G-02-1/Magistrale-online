package dgc.server;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.rmi.server.Unreferenced;

public class HelloImpl extends UnicastRemoteObject
		implements Hello, Unreferenced {	
	
	public HelloImpl() throws RemoteException  {
		super();
   	}
   	public String sayHello() throws RemoteException {	
		return "Hello!";
   	}
   	public MessageObject getMessageObject() throws RemoteException {
		return new MessageObjectImpl();
   	}

	public void finalize() throws Throwable {
		super.finalize();
		System.out.println( "HelloImpl: Finalize called" );
 	}
	
	@Override
	public void unreferenced() {
		System.out.println( "HelloImpl: Unreferenced" );
	}
	
} // class HelloImpl 