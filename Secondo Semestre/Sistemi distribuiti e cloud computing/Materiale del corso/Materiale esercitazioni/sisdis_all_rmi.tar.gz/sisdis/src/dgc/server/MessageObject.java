package dgc.server;

public interface MessageObject extends java.rmi.Remote {
	int getNumberFromObject() throws java.rmi.RemoteException;
	int getNumberFromClass() throws java.rmi.RemoteException;
}