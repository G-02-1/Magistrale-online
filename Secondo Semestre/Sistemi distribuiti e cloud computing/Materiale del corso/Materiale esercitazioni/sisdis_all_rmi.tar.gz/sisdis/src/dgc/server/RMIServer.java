package dgc.server;

import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;

public class RMIServer {
	private static final int PORT = 10007;
	private static final String HOST_NAME = "router";
	private static RMIServer rmi;

	public RMIServer() throws RemoteException, MalformedURLException,NotBoundException {
		LocateRegistry.createRegistry(PORT);
		System.out.println("Registry created on host computer " + HOST_NAME
				+ " on port " + Integer.toString(PORT));
		Hello hello = new HelloImpl();
		System.out
				.println("Remote Hello service implementation object created");
		String urlString = "//" + HOST_NAME + ":" + PORT + "/" + "Hello";
		Naming.rebind(urlString, hello);
		System.out.println("Bindings Finished, waiting for client requests.");
	}

	public static void main(String[] args) {
		try {
			rmi = new RMIServer();
		} catch (RemoteException e) {
			System.out.println("Error starting service");
			e.printStackTrace();
		} catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (NotBoundException e) {
			System.out.println("Error: an attempt is "
					+ "made to lookup or unbind in the registry "
					+ "a name that has no  associated binding. Not Bound");
			e.printStackTrace();
		}
	}

} // class RMIServer