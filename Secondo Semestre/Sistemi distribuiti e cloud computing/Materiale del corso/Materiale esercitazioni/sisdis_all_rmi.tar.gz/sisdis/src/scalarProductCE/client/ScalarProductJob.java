package scalarProductCE.client;

import java.util.Vector;

import computeEngine.client.Job;

public class ScalarProductJob implements Job {
	int id = 0;
	public Object run(Object parameters) {
		// supposing that “parameters” is a Vector of 2 elements (v1 and v2)
		Vector v = (Vector) parameters;
		Vector v1 = (Vector) v.get(0);
		Vector v2 = (Vector) v.get(1);
		int ret = 0;
		for (int i = 0; i < v1.size(); i++)
			ret += ((Integer) v1.get(i)).intValue()
					* ((Integer) v2.get(i)).intValue();
		return new Integer(ret);
	}

	@Override
	public int getId() {
		return id;
	}

	@Override
	public void setId(int id) {
		this.id = id;
	}
}