package scalarProductCE.client;

import java.util.Vector;

import computeEngine.client.ComputeThread;

public class ScalarProductCEClient {
	public static void main(String args[]) {
		// create and populate “v1” and “v2” (in a naive way)
		Vector v1 = new Vector();
		Vector v2 = new Vector();
		for (int i = 1; i <= 100; i++) {
			v1.add(new Integer(i));
			v2.add(new Integer(1));
		}
		// split “v1” and “v2” in 3 parts and create 3 “vparX” instances
		// (containing the
		// paramenters to be passed)
		Vector vpar1 = new Vector();
		vpar1.add(extract(v1, 0, 32));
		vpar1.add(extract(v2, 0, 32));
		Vector vpar2 = new Vector();
		vpar2.add(extract(v1, 33, 66));
		vpar2.add(extract(v2, 33, 66));
		Vector vpar3 = new Vector();
		vpar3.add(extract(v1, 67, 99));
		vpar3.add(extract(v2, 67, 99));
		ComputeThread ct1 = new ComputeThread(new ScalarProductJob(), vpar1,
				"localhost");
		ComputeThread ct2 = new ComputeThread(new ScalarProductJob(), vpar2,
				"localhost");
		ComputeThread ct3 = new ComputeThread(new ScalarProductJob(), vpar3,
				"localhost");
		ct1.start();
		ct2.start();
		ct3.start();
		try {
			ct1.join();
			ct2.join();
			ct3.join();
		} catch (InterruptedException e) {
			System.out.println(e);
		}
		// compute the final result (obtained as summarization of the partial
		// results)
		System.out.println(((Integer) ct1.getResult()).intValue()
				+ ((Integer) ct2.getResult()).intValue()
				+ ((Integer) ct3.getResult()).intValue());
	}

	private static Vector extract(Vector v, int from, int to) {
		Vector ret = new Vector();
		for (int i = from; i <= to; i++)
			ret.add(v.get(i));
		return ret;
	}
}