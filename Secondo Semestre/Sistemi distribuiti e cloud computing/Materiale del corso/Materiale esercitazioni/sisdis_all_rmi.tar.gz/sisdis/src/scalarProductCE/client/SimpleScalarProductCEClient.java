package scalarProductCE.client;

import java.rmi.Naming;
import java.util.Vector;

import computeEngine.server.ComputeEngine;

public class SimpleScalarProductCEClient {
	public static void main(String args[]) {
		// create and populate “v1” and “v2” (in a naive way)
		Vector v1 = new Vector();
		Vector v2 = new Vector();
		for (int i = 1; i <= 100; i++) {
			v1.add(new Integer(i));
			v2.add(new Integer(1));
		}
		int result = 0;
		try {
			ComputeEngine ce = (ComputeEngine) Naming
					.lookup("rmi://localhost:1099/computeEngine");
			// create the “vpar” instance (containing the paramenters to be
			// passed)
			Vector vpar = new Vector();
			vpar.add(v1);
			vpar.add(v2);
			// invoke the remote operation
			Integer res = (Integer) ce.execute(new ScalarProductJob(), vpar);
			result = res.intValue();
		} catch (Exception e) {
			System.out.println(e);
		}
		System.out.println(result);
	}
}