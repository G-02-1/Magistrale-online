package computeEngine.server;

import java.rmi.Remote;
import java.rmi.RemoteException;

import computeEngine.client.Job;

public interface ComputeEngine extends Remote {
	public Object execute(Job j, Object parameters) throws RemoteException;
}