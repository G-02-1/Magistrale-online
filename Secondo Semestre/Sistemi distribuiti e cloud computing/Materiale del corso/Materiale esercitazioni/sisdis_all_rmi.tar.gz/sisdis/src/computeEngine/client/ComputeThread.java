package computeEngine.client;

import java.rmi.Naming;

import computeEngine.server.ComputeEngine;

public class ComputeThread extends Thread {
	private Job job;
	private Object parameters;
	private String host;
	private Object result;

	public ComputeThread(Job job, Object parameters, String host) {
		this.job = job;
		this.parameters = parameters;
		this.host = host;
		result = null;
	}

	public void run() {
		try {
			ComputeEngine ce = (ComputeEngine) Naming.lookup("rmi://" + host
					+ ":1099/computeEngine");
			result = ce.execute(job, parameters);
			System.out.println("ComputeThread result=" + result);
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	public Object getResult() {
		return result;
	}
}