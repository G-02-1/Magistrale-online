package computeEngine.server;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

import computeEngine.client.Job;

public class ComputeEngineImpl extends UnicastRemoteObject implements
		ComputeEngine {
	public ComputeEngineImpl() throws RemoteException {
		super();
	}

	public Object execute(Job j, Object parameters) throws RemoteException {
		System.out.println("Executing job "+j.getId());
		return j.run(parameters);
	}
}