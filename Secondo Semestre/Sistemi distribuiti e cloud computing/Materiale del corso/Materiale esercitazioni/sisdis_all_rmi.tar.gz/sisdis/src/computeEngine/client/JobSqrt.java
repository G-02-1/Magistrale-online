package computeEngine.client;

public class JobSqrt implements Job {
	
	int id = 0;
	
	@Override
	public Object run(Object parameters) {
		Double value = (Double) parameters;
		return new Double(Math.sqrt(value));
	}

	@Override
	public int getId() {
		return id;
	}

	@Override
	public void setId(int id) {
		this.id = id;
	}

}
