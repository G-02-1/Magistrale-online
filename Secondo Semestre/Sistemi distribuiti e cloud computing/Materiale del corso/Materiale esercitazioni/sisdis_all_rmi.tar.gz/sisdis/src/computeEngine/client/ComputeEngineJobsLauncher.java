package computeEngine.client;

public class ComputeEngineJobsLauncher {

	public static void main(String[] args) {
		Double value = new Double(25);
		Job job = new JobSqrt();
		job.setId(1);
		ComputeThread t = new ComputeThread(job, value, "localhost");
		t.start();
		
		Double value2 = new Double(36);
		Job job2 = new JobSqrt();
		job2.setId(2);
		ComputeThread t2 = new ComputeThread(job2, value2, "localhost");
		t2.start();

	}

}
