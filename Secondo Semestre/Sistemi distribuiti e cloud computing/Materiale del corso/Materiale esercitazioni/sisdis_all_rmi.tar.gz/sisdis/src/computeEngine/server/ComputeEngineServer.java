package computeEngine.server;

import java.rmi.Naming;

public class ComputeEngineServer {
	public static void main(String args[]) {
		try {
			ComputeEngineImpl cei = new ComputeEngineImpl();
			Naming.rebind("computeEngine", cei);
			System.out.println("ComputeEngineServer ready.");
		} catch (Exception e) {
			System.out.println(e);
		}
	}
}