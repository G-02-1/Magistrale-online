package congresso.server;

import java.rmi.Naming;
import java.rmi.RMISecurityManager;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

public class ServerCongressoImpl extends UnicastRemoteObject implements
		ServerCongresso {
	static Programma prog[];

	// Costruttore
	public ServerCongressoImpl() throws RemoteException {
		super();
	}

	// Richiesta di prenotazione
	public int registrazione(int giorno, String sessione, String speaker)
			throws RemoteException {
		int numSess = -1;
		System.out.println("Server RMI: richiesta registrazione con parametri");
		System.out.println("giorno = " + giorno);
		System.out.println("sessione = " + sessione);
		System.out.println("speaker = " + speaker);

		String sessionPrefix = sessione.substring(0, 1);
		int sessionId = Integer.parseInt(sessione.substring(1));
		if (sessionPrefix.equals("S") && sessionId >= 1 && sessionId <= 12) {
			numSess = sessionId;
		}

		/*
		 * Se i dati sono sbagliati significa che sono stati trasmessi male e
		 * quindi lancia un’eccezione
		 */
		if (numSess == -1)
			throw new RemoteException();

		if (giorno < 1 || giorno > 3)
			throw new RemoteException();

		return prog[giorno - 1].registra(numSess, speaker);
	}// registrazione

	// Richiesta di programma
	public Programma programma(int giorno) throws RemoteException {
		System.out.println("Server RMI: richiesto programma del giorno "
				+ giorno);
		if (giorno < 1 || giorno > 3)
			throw new RemoteException();
		return prog[giorno - 1];
	}

	// Avvio del Server RMI
	public static void main(String[] args) {
		// creazione programma
		prog = new Programma[3];
		for (int i = 0; i < 3; i++)
			prog[i] = new Programma();

		final int REGISTRYPORT = 1099;
		String registryHost = "localhost";
		String serviceName = "ServerCongresso";

		// Impostazione del SecurityManager
		try {
			if (System.getSecurityManager() == null)
				System.setSecurityManager(new RMISecurityManager());
			// Registrazione del servizio RMI
			String completeName = "//" + registryHost + ":" + REGISTRYPORT
					+ "/" + serviceName;
			ServerCongressoImpl serverRMI = new ServerCongressoImpl();
			Naming.rebind(completeName, serverRMI);
		} catch (Exception e) {
			System.err.println("Server RMI \"" + serviceName + "\": "
					+ e.getMessage());
			e.printStackTrace();
			System.exit(1);
		}// try/catch
	}// main
}
