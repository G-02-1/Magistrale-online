package congresso.client;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.rmi.Naming;
import java.rmi.RMISecurityManager;

import congresso.server.Programma;
import congresso.server.ServerCongresso;

class ClientCongresso {
	public static void main(String[] args) {
		final int REGISTRYPORT = 1099;
		String registryHost = null;
		String serviceName = "ServerCongresso";
		BufferedReader stdIn = new BufferedReader(new InputStreamReader(
				System.in));
		// Controllo dei parametri della riga di comando
		try {
			if (args.length != 1) {
				System.out.println("Syntax: ClientCongresso NomeHost ");
				System.exit(1);
			}
			registryHost = args[0];

			// Impostazione del SecurityManager
			if (System.getSecurityManager() == null)
				System.setSecurityManager(new RMISecurityManager());

			// Connessione al servizio RMI remoto
			String completeName = "//" + registryHost + ":" + REGISTRYPORT
					+ "/" + serviceName;
			ServerCongresso serverRMI = (ServerCongresso) Naming
					.lookup(completeName);

			// Ciclo di interazione con l’utente
			System.out.println("\nRichieste di servizio fino a fine file");
			System.out
					.print("Servizio (R=Registrazione,P=Programma del congresso): ");
			String service;
			boolean ok;
			while ((service = stdIn.readLine()) != null) {
				if (service.equals("R")) {
					// giornata
					ok = false;
					int g = 0;
					System.out.print("Giornata (1-3)? ");
					while (ok != true) {
						g = Integer.parseInt(stdIn.readLine());
						if (g < 1 || g > 3) {
							System.out.println("Non valida");
							System.out.print("Giornata (1-3)? ");
							continue;
						} else
							ok = true;
					}// while

					// sessione
					ok = false;
					String sess = "";
					System.out.print("Sessione (S1 - S12)? ");
					while (ok != true) {
						sess = stdIn.readLine();
						String sessionPrefix = sess.substring(0, 1);
						int sessionId = Integer.parseInt(sess.substring(1));

						if (!sessionPrefix.equals("S") || sessionId < 1
								|| sessionId > 12) {
							System.out.println("Non valida");
							System.out.print("Sessione(S1-S12)?");
							continue;
						} else
							ok = true;
					}
					// speaker
					System.out.print("Speaker? ");
					String speak = stdIn.readLine();
					// nessun controllo, qualsiasi stringa potrebbe essere un
					// nome accettabile
					// supponiamo input corretto

					if (serverRMI.registrazione(g, sess, speak) == 0)
						System.out.println("Registrazione di " + speak
								+ " effettuata per giornata " + g
								+ " 	sessione " + sess);
					else
						System.out
								.println("Registrazione non effettuata, sessione completa");
				} // if(service.equals("R"))
					// stampa programma
				else if (service.equals("P")) {
					int g = 0;
					ok = false;
					System.out.print("Giornata (1-3)? ");
					while (ok != true) {
						g = Integer.parseInt(stdIn.readLine());
						if (g < 1 || g > 3) {
							System.out.println("Giorn. non valida");
							System.out.print("Giornata (1-3)? ");
							continue;
						} else
							ok = true;
					}// while

					Programma prog = serverRMI.programma(g);
					System.out.println("Programma giornata " + g + "\n");
					prog.stampa();
				} // if (service.equals("P"))
				else
					System.out.println("Servizio non dispon.");
				System.out
						.print("Servizio (R=Registrazione, P=Programma del congresso): ");
			} // !EOF
		} catch (Exception e) {
			System.err.println("ClRMI:" + e.getMessage());
			e.printStackTrace();
			System.exit(1);
		}
	} // main
} // ClientCongresso