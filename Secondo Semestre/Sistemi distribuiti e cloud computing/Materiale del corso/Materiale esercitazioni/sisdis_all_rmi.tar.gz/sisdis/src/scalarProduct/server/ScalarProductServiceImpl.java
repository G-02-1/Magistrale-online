package scalarProduct.server;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

public class ScalarProductServiceImpl extends UnicastRemoteObject implements
		ScalarProductService {
	public ScalarProductServiceImpl() throws RemoteException {
		super();
	}

	public int scalarProduct(int[] v1, int[] v2) throws RemoteException {
		int ret = 0;
		for (int i = 0; i < v1.length; i++)
			ret += v1[i] * v2[i];
		return ret;
	}
}