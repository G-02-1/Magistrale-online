package scalarProduct.client;

import java.rmi.Naming;

import scalarProduct.server.ScalarProductService;

public class SimpleScalarProductClient {
	public static void main(String args[]) {
		int[] v1 = new int[100];
		int[] v2 = new int[100];
		// populate v1 e v2 (in a naive way)
		for (int i = 0; i <= 99; i++) {
			v1[i] = i + 1;
			v2[i] = 1;
		}
		int result = 0;
		try {
			ScalarProductService spe = (ScalarProductService) Naming
					.lookup("rmi://localhost:1099/scalarProductService");
			result = spe.scalarProduct(v1, v2);
		} catch (Exception e) {
			System.out.println(e);
		}
		System.out.println(result);
	}
}