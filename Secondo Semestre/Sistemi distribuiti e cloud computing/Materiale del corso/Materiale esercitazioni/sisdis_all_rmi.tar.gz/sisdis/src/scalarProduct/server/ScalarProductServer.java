package scalarProduct.server;

import java.rmi.Naming;

public class ScalarProductServer {
	public static void main(String args[]) {
		try {
			ScalarProductServiceImpl spsi = new ScalarProductServiceImpl();
			Naming.rebind("scalarProductService", spsi);
			System.out.println("ScalarProductServer ready.");
		} catch (Exception e) {
			System.out.println(e);
		}
	}
}