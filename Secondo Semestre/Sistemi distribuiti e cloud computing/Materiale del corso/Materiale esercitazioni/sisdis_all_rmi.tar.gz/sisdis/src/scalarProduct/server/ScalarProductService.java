package scalarProduct.server;

import java.rmi.Remote;
import java.rmi.RemoteException;

public interface ScalarProductService extends Remote {
	public int scalarProduct(int[] v1, int[] v2) throws RemoteException;
}